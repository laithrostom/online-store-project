
SECRET_KEY = 'dummy'
DEBUG = True
ALLOWED_HOSTS = []
INSTALLED_APPS = ['django.contrib.contenttypes', 'django.contrib.auth', 'rest_framework', 'store']
MIDDLEWARE = []
ROOT_URLCONF = 'online_store.urls'
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': 'db.sqlite3',
    }
}
USE_TZ = True
